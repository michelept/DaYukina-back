package com.yukina.spa.DaYukina;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaYukinaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaYukinaApplication.class, args);
	}

}
