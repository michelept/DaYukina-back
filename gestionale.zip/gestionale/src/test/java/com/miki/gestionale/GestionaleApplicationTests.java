package com.miki.gestionale;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionaleApplicationTests {

	@Test
	void contextLoads() {
	}

}
